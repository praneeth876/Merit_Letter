package com.BaseClass;

import org.openqa.selenium.WebDriver;

import com.GenericGlobal.ExcelUtility;
import com.GenericGlobal.JavaUtility;
import com.GenericGlobal.LogUtility;
import com.GenericGlobal.PropertyFileUtiltity;
import com.GenericGlobal.ScreenShotUtility;
import com.GenericGlobal.Validations;
import com.GenericGlobal.WebDriverUtilities;
import com.PageFactory.AddToBasket;
import com.PageFactory.LoginPageNopCommerce;
import com.PageFactory.LoginSignUpPage;
import com.PageFactory.ProductSelection;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

/**
 * Base class is used create and initialize all the different objects and also
 * used to implements the common methods used for the application
 * 
 * @author PraneethReddy
 * 
 */
public class BaseTest {
	public static WebDriver driver;
	public PropertyFileUtiltity propUtil = new PropertyFileUtiltity();
	public String browser = propUtil.getBrowser();
	public String url = propUtil.getAppUrl();
	public LoginPageNopCommerce nopCommerce;
	public WebDriverUtilities webUtil = new WebDriverUtilities(driver);
	public LogUtility log = new LogUtility();
	//public ExcelUtility excel = new ExcelUtility();
	public ExtentSparkReporter sparkReports;
	public ExtentReports reports;
	public ExtentTest test;
	public ScreenShotUtility srcUtil = new ScreenShotUtility();
	public String reportPath = propUtil.getExtentReportPath();
	public Validations validations = new Validations();
	public JavaUtility javaUtil = new JavaUtility();
	public LoginSignUpPage login;
	public ProductSelection product;
	public AddToBasket addToBasket;
	
	public String excelPath = propUtil.getExcelPath();
	public String excelSheetName = propUtil.getSheetName();
	//public String userLoginData = excel.getData(excelSheetName, 7, 2);
	public static String priceOfProduct;
	public String price;
	public String totalPriceOfProduct;
	//public String basketPageText = excel.getData(excelSheetName, 1, 4);
	public String basketPageUrl;
	public String emptyBasketExpMessage="no items in your basket";
	public String emptyBasketMessage;
}
