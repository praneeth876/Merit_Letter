package com.PageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.GenericGlobal.ExcelUtility;

public class LoginPageNopCommerce {
	WebDriver driver;
	ExcelUtility excel;

	public LoginPageNopCommerce(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		excel=new ExcelUtility();
	}

	@FindBy(css = "#Email")
	WebElement emailEle;
	@FindBy(css = ".password")
	WebElement passwordEle;
	@FindBy(css = ".button-1.login-button")
	WebElement loginBtn;

	public void launchBrowser() {
		driver.manage().window().maximize();
	}

	public void enterEmail(String email) throws InterruptedException {
		
		//String email=excel.getData("Sheet2", 1, 0);
		
		emailEle.clear();
		Thread.sleep(3000);
		emailEle.sendKeys(email);
	}

	public void enterPassword(String password) throws InterruptedException {
//		String password=excel.getData("Sheet2", 1, 1);
		passwordEle.clear();
		Thread.sleep(3000);
		passwordEle.sendKeys(password);
	}

	public void clickOnLoginBtn() {
		loginBtn.click();
	}

	public void validateDashboardPage() {
		String actualTitle = driver.getTitle();
		String expected = "Dashboard";
		if (actualTitle.contains(expected)) {
			System.out.println("Dashboard page is displayed");
		} else {
			System.out.println("not displayed");
		}
	}
}
