package com.PageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.BaseClass.BaseTest;

/**
 * This class contains all the methods used for selecting a product and also
 * validating the selected product
 *
 * @author PraneethReddy
 */

public class ProductSelection extends BaseTest {
	WebDriver driver;

	public ProductSelection(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(css = "[class='dropdown-toggle meganav-shop']")
	public WebElement ShopByCategory;
	@FindBy(xpath = "//div[@class='tab-pane active']/following::a[text()='Potato, Onion & Tomato']")
	public WebElement productSubCategory;
	@FindBy(xpath = "//a[text()='Onion (Loose)']")
	public WebElement itemSelection;
	@FindBy(css = "div.d8V7B")
	public WebElement viewSelectedProduct;
	@FindBy(css = "[class='_16DQ1']")
	public WebElement productImageDisplay;
	@FindBy(css = "[data-qa='productPrice']")
	public WebElement productPrice;

	public void hoverOnShopByCategory() throws InterruptedException {
		Thread.sleep(30000);
		webUtil.visibilityOfElement(20, ShopByCategory);
		webUtil.moveToElement(ShopByCategory);
		log.info("Successufully mouse hovered on Shop By Category DropDown");
	}

	public void chooseProductsubCategory() {
		webUtil.elementToBeClickable(10, productSubCategory);
		try {
			webUtil.javaScriptToClick(productSubCategory);
		} catch (Exception e) {
			e.printStackTrace();
		}
		log.info("Product sub category is successfully choosed and clicked");
	}

	public void selectProduct() {
		webUtil.elementToBeClickable(20, itemSelection);
		try {
			webUtil.javaScriptToClick(itemSelection);
			webUtil.moveToElement(productPrice);
			Thread.sleep(5000);
			priceOfProduct = webUtil.getElementText(productPrice);
			System.out.println(priceOfProduct);
		} catch (Exception e) {
			e.printStackTrace();
		}
		log.info("Product is successfully selected");
	}

	public void getProductPrice() throws InterruptedException {

		webUtil.visibilityOfElement(5, productPrice);
		webUtil.scrollDown(0, 100);
		try {
			webUtil.moveToElement(productPrice);
			priceOfProduct = webUtil.getElementText(productPrice);
			System.out.println(priceOfProduct);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void mouseHoverOnSelectedProduct() {
		webUtil.visibilityOfElement(10, viewSelectedProduct);
		try {
			webUtil.moveToElement(viewSelectedProduct);
		} catch (Exception e) {
			e.printStackTrace();
		}
		log.info("Mouse hover on selected element is done successfully");
	}

	public void productImageValidation() {
		webUtil.visibilityOfElement(20, productImageDisplay);
		validations.isDisplayed(productImageDisplay, true, "Product Image is not displayed");
		log.warn("Product image is displayed successfully");
	}

}
