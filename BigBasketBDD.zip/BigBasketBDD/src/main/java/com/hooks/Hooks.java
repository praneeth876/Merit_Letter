package com.hooks;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.safari.SafariDriver;
import com.BaseClass.BaseTest;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Hooks extends BaseTest {
	@Before
	public void setUp() {
		switch (browser) {
		case "chrome":
			chromeDriver();
			break;
		case "edge":
			edgeDriver();
			break;
		case "fireFox":
			fireFoxDriver();
			break;
		case "safari":
			safariDriver();
			break;
		default:
			System.out.println("Choose existing browser");
		}
		log.info(browser + " browser is launched successfully");

		getUrl(url);
		log.info("Successfully navigated to " + url + " url");
	}


	@After
	public void tearDown() {
		Quit();
		log.fatal("browser is closed successfully");
	}

	
	//Initializing chrome driver
	public void chromeDriver() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
	}

	//Initializing firefox driver
	public void fireFoxDriver() {
		WebDriverManager.firefoxdriver().setup();
		driver = new FirefoxDriver();
	}

	//Initializing edge driver
	public void edgeDriver() {
		WebDriverManager.edgedriver().setup();
		driver = new EdgeDriver();
	}

	//Initializing safari driver
	public void safariDriver() {
		WebDriverManager.safaridriver().setup();
		driver = new SafariDriver();
	}

	//Used to get the required application
	public void getUrl(String Url) {
		driver.get(Url);
	}

	//Used to close the browser
	@After
	public void Quit() {
		driver.quit();
	}
}
