package com.testRunner;

import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;



@RunWith(Cucumber.class)	
@CucumberOptions(features=".\\FeatureFiles\\NopCommerceLogin.feature",glue={"stepDefinitions","com.hooks"}
,plugin= {"pretty", "html:target/cucumber-html-reports"}
,dryRun = false
	)
public class TestRunner {
	
}
