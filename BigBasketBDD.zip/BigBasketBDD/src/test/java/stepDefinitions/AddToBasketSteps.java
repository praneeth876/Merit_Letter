package stepDefinitions;

import com.BaseClass.BaseTest;
import com.PageFactory.AddToBasket;
import com.PageFactory.ProductSelection;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AddToBasketSteps extends BaseTest {

	@When("user is able to click on add to basket button")
	public void user_is_able_to_click_on_add_to_basket_button() throws InterruptedException {
		addToBasket = new AddToBasket(driver);
		addToBasket.clickOnAddToBasketButton();
		addToBasket.mouseHoverOnMyBasket();
		addToBasket.validateMouseHoverOnMyBasket();
		addToBasket.clickOnViewBasketAndCheckOutButton();
	}
	@Then("validate the price in basket")
	public void validate_the_price_in_basket() {
		addToBasket.basketPageValidation();
		addToBasket.getTotalProductPrice();
		addToBasket.priceValidation();
	}
	@Then("user is able to delete all products in the basket")
	public void user_is_able_to_delete_all_products_in_the_basket() {
		addToBasket.clearBasket();
		addToBasket.clickOnEmptyPopUpOkButton();
	}
	@Then("validate empty basket")
	public void validate_empty_basket() {
		addToBasket.emptyBasketValidation();
	}
}
