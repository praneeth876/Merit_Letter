package stepDefinitions;

import com.BaseClass.BaseTest;
import com.GenericGlobal.ExcelUtility;
import com.PageFactory.LoginPageNopCommerce;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class NopCommLoginPageSteps extends BaseTest{
		
	ExcelUtility excel=new ExcelUtility();
	
	@Given("User is able to navigate to app")
	public void user_is_able_to_navigate_to_app() {
		nopCommerce=new LoginPageNopCommerce(driver);
		nopCommerce.launchBrowser();
	}
	
	@When("Update username to email field")
	public void update_username_to_email_field() throws InterruptedException {
		nopCommerce.enterEmail(excel.getData("Sheet2", 1, 0));
	}
	@When("Update password to password field")
	public void update_password_to_password_field() throws InterruptedException {
		nopCommerce.enterPassword(excel.getData("Sheet2", 1, 1));
	}
	

	@When("Click on login button")
	public void click_on_login_button() {
		nopCommerce.clickOnLoginBtn();
	}

	@Then("validate Dashboard page is displayed")
	public void validate_dashboard_page_is_displayed() {
		nopCommerce.validateDashboardPage();
	}
	

}
