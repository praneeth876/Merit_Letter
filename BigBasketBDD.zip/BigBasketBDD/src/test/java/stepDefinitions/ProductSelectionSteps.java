package stepDefinitions;

import com.BaseClass.BaseTest;
import com.PageFactory.LoginSignUpPage;
import com.PageFactory.ProductSelection;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
public class ProductSelectionSteps extends BaseTest{


@Given("the big basket home page is displayed")
public void the_big_basket_home_page_is_displayed() {
	login=new LoginSignUpPage(driver);
	login.clickOnLoginSignUpButton();
	login.enterUserLoginData(userLoginData);
	login.clickOnContinueButton();
	log.info("Successfully logged in to the Big Basket Application");
}

@When("Choose a product category")
public void choosing_a_product_category() throws InterruptedException {
product=new ProductSelection(driver);
product.hoverOnShopByCategory();
product.chooseProductsubCategory();
}

@When("user is able to select a product")
public void user_is_searching_to_select_a_product() throws InterruptedException {
product.selectProduct();
product.getProductPrice();
}

@Then("validate the selected product")
public void validate_the_selected_product() throws InterruptedException {
product.mouseHoverOnSelectedProduct();
product.productImageValidation();
}
	
}
