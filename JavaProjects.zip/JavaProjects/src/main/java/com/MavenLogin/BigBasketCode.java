package com.MavenLogin;

public class BigBasketCode {
//	
//	public void getProductDetails() {
//	 quantity=webUtil.getElementText(productQuantity);
//		//String stdPrice=webUtil.getElementText();
//		 productsubTotalPrice=webUtil.getElementText(productSubTotal);
//	}
//	
//	
//	
//	
//	public void convertPrice() {
//		
//		String price = priceOfProduct;
//		char[] ch = price.toCharArray();
//		String temp = " ";
//		char a;
//		for (int i = 0; i < ch.length; i++) {
//			a = price.charAt(i);
//
//			if ((a >= '0' && a <= '9') || (a == '.')) {
//				temp = temp + a;
//			}
//		}
//	
//		selectedQuantity = Double.parseDouble(quantity);
//		 priceConvert = Double.parseDouble(temp);
//	}
//	
//	
//	public void quantityIncrease(double selectedQuantity, double reqQuantity, double priceConvert) {
//		
//		
//		double	stdprice = priceConvert;
//	
//			for (double i = selectedQuantity; i <= reqQuantity; i++) {
//
//				if (selectedQuantity == reqQuantity) {
//					stdprice = stdprice * reqQuantity;
//
//				} else {
//					webUtil.javaScriptToClick(addProductQuantity);
//				}
//			}
//			System.out.println(stdprice);
//		}
}
