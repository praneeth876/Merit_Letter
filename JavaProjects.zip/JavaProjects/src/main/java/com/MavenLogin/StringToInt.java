package com.MavenLogin;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class StringToInt {
//	@FindBy(css = "input._253qQJ")
//	WebElement quantity;
//	@FindBy(xpath = "//button[text()=\"+\"]")
//	WebElement addNoOfProductsInCart;
//	@FindBy(xpath = "//button[text()=\"-\"]")
//	WebElement minusNoOfProductsInCart;
////public static  String removeChars() {
////		
////	String priceAfter="$27,000";
////	String temp=" ";
////		char[] ch=priceAfter.toCharArray();
////		
////		char c;
////		for(int a=0;a<ch.length;a++) {
////			 c=priceAfter.charAt(a);
////	    if((c>='0'&& c<='9')) {
////	    	//System.out.print(c);
////	     temp=temp+c;
////	    	
////	    }
////		
////	}
////	return temp;
////	
//	//}
//    
//public static void main(String[] args) {
////	try {
////	int num=Integer.parseInt(removeChars());
////	System.out.println(num);
////	}catch(NumberFormatException e) {
////		e.getMessage();
////	}
//	
//	
//	quantityAndPriceValidation(5);
//	
//	
//}
//
//static int totalPrice = 0;
//
//public static  void quantityAndPriceValidation(int noOfItems) {
//
//	//String Quantity = quantity.getAttribute("value");
//	String Quantity="1";
//
//	int qt = Integer.parseInt(Quantity);
//	int price = 27000;
//for(int i=0;i<noOfItems;i++) {
//	if (qt <= noOfItems) {
//		//System.out.println(qt);
//		totalPrice = qt * price;
//		//webUtil.click(addNoOfProductsInCart);
//		qt++;
//		
//	}else if(qt>noOfItems) {
//		totalPrice = qt * price;
//		//webUtil.click(minusNoOfProductsInCart);
//		qt--;
//	}
//        System.out.println("Total :" + totalPrice);
//}
//
//}
//
////String s;
//	List<Character>list;
//	
//	public List<Character> removeChars() {
//		
//		list=new ArrayList<>();
//		
//		char[] ch=priceAfter.toCharArray();
//		char c;
//		for(int a=0;a<ch.length;a++) {
//			 c=priceAfter.charAt(a);
//	    if((c>='0'&& c<='9')) {
//	    	System.out.println(c);
//	    	list.add(c);
//	    }
//			
//		//list.add(c);
//	}
//	//System.out.println(list.toString());
//	return list;
//	
//	}
//	
//  
//	int totalPrice = 0;
//
//	public void quantityAndPriceValidation(int noOfItems) {
//
//		String Quantity = quantity.getAttribute("value");
//
//		int qt = Integer.parseInt(Quantity);
//		int price = Integer.parseInt(removeChars().toString());
//
//		if (qt < noOfItems) {
//			System.out.println(qt);
//			totalPrice = qt * price;
//			webUtil.click(addNoOfProductsInCart);
//			qt++;
//		}else if(qt>noOfItems) {
//			totalPrice = qt * price;
//			webUtil.click(minusNoOfProductsInCart);
//			qt--;
//		}
//	        System.out.println("Total :" + totalPrice);
//	}
//
//
//
//
//
//
//
//
//
//
	
	
	
public static void main(String[] args) {
	String a="Rs 149";
	
	String b=".00";
	
	StringBuffer bf=new StringBuffer(a);
	bf.append(b);
	
	System.out.println(a);
	
}

}
