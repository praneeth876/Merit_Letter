package com.MavenLogin;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.chainsaw.Main;



public class UserLogin {
	public static void main(String[] args) {
		fizzBuzz(15);
	}

//	public int loginPage(String Username,String Password) throws IOException {
//		
//		FileInputStream file=new FileInputStream("./config.properties");
//		Properties prop=new Properties();
//		prop.load(file);
//		String username=prop.getProperty("userName");
//		String password=prop.getProperty("password");
//		if(username.equals(Username) && password.equals(Password)) {
//			System.out.println("Login Successful");
//			return 1;
//		}
//		else {
//			System.out.println("In valid Credentials");
//			return 0;
//		}
//	}
	 public static void fizzBuzz(int n) {

		 for(int i=0;i<n;i++){
		 if(i%3==0&&i%5==0){
		     System.out.println("FizzBuzz");
		 }else if(i%3==0&& i%5!=0){
		     System.out.println("Fizz");
		 }else if(i%5==0&& i%3!=0){
		 System.out.println("Buzz");
		     }else {
		         System.out.println(i);
		     }

		 }
		
}}
