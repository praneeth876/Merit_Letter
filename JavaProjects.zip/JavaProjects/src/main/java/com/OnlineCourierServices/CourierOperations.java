package com.OnlineCourierServices;

public interface CourierOperations {

	public void payment(double weight);
	public void confirmOrder(boolean order);
	public void pickUp();
	public void delivery();
	
	
	
	
	
	
}
