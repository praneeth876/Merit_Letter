package com.OnlineCourierServices;

public class CourierPortal implements CourierOperations{

	String itemName;
	double weight;
	int price;
	
	
	public CourierPortal(){
		
		
		
	}
	
	
	
	
	
	
	public void payment(double weight) {
		
		if (weight>=1 && weight<=10) {
			price=200;
		}
		else if(weight>=20 && weight <=30) {
			price=500;
		}
	}

   public void confirmOrder(boolean order) {
		
		if (order) {
			System.out.println("Order is confirmed");
			
		}
		else {
			System.out.println("order is not confirmed");
		}
	}
   
   public void vehicleType() {
	   if(weight<=200) {
		   System.out.println("Auto");
	   }else if(weight>200 && weight <500) {
		   System.out.println("small lorry");
	   }else if(weight>500) {
		   System.out.println("Big lorry");
	   }
	   
   }
   

	public void pickUp() {
		
		
	}

	public void delivery() {
		
		
	}

	public static void main(String[] args) {
		CustomerAccount ca=new CustomerAccount("Venn","pranni@gmail.com","9515216200");
		ca.display();
		
	}








	
	
	
	
}
