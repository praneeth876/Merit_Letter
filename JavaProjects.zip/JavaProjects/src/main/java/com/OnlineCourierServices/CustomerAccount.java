package com.OnlineCourierServices;

public class CustomerAccount extends CustomerAddress {
	
	static String CourierCompanyName="Delhivery";
	
	
	String name;
	String email;
	String mobNo;
	
	
public CustomerAccount(String name,String email,String mobNo) {
	this.name=name;
	 this.email=email;
	 this.mobNo=mobNo;
	 
	}
	
public void display() {
	
	System.out.println("\nCourierCompanyName : "+CourierCompanyName+
			           "\n name              : "+name+
			           "\n email             : "+email+
			           "\n mobNo             : "+mobNo+
			           "\n doorNo            : "+doorNo+
			           "\n village           : "+village+
			           "\n mandal            : "+mandal+
			           "\n city              : "+city+
			           "\n state             : "+state+
			           "\n pincode           : "+pinCode);
	
}


}