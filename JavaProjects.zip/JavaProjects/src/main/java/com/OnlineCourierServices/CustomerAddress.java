package com.OnlineCourierServices;

public class CustomerAddress {

	int doorNo;
	String village;
	String mandal;
	String city;
	String state;
	String pinCode;
	
	public CustomerAddress(){
		this.doorNo=143;
		this.village="chennuru";
		this.mandal="pileru";
		this.city="Chittor";
		this.state="Andhra Pradesh";
		this.pinCode="524312";
		
	}
	
	
}
