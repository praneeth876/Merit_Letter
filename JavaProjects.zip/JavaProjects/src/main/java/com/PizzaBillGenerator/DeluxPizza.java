package com.PizzaBillGenerator;

import java.util.Scanner;

//import com.PizzaBillGenerator.Pizza;
public class DeluxPizza extends Pizza{

	String PizzaType;
	double price;
	Scanner scan=new Scanner(System.in);
	
	public DeluxPizza(String pizzaType,double price) {
		super(pizzaType);
		this.PizzaType=pizzaType;
		this.price=price;
		
		System.out.println("enter no of extra cheese packets");
		super.addExtraCheese(0);
		System.out.println("enter no of extra toppings");
		super.addExtraToppings(0);
	}

//	 public void addTakeAways(String coverSize) {
//			if(coverSize.equals("small")) {
//				this.price=price+20;
//			}
//			else {
//				this.price=price+40;
//			}
//			
//			System.out.println("Price with extra takeaway :"+this.price);
//		}
//	
//	  public void totalBill() {
//	    	System.out.println("total bill :"+this.price);
//	    }
	
	

	
	
	
}
