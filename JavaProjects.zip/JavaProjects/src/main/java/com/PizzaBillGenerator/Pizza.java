package com.PizzaBillGenerator;

public class Pizza {

	static String shopName="Dominos";
	static String location="Madhapur";
	
	String pizzaType;
	
	double price;
	
	public Pizza(String pizzaType ) {
		this.pizzaType=pizzaType;
		if(pizzaType.equals("veg")) {
			this.price=100;
		}else if(pizzaType.equals("Nonveg")) {
			this.price=200;
			
		}
		
		
	}
	
	public double addExtraCheese(int noOfPackets) {
		
		this.price=this.price+100*noOfPackets;
		return price;
	}
	public double addExtraToppings(int noOfToppings) {
		 return this.price=this.price+100*noOfToppings;
	}
    public void addTakeAways(String coverSize) {
		if(coverSize.equals("small")) {
			this.price=this.price+20;
		}
		else {
			this.price=this.price+40;
		}
		
		System.out.println("Price with extra takeaway :"+this.price);
	}
    
    
    
    void ShopDetails() {
    	System.out.println("Welcome to pizza world\n"+
                            "Shop Name : "+shopName+
                            "\nlocation : "+location);
                           
    }
    public void item() {
    	 System.out.println("\nType of pizza : "+this.pizzaType);
    }
	
    
    public void totalBill() {
    	System.out.println("total bill :"+this.price);
    }
	
	
	
}
