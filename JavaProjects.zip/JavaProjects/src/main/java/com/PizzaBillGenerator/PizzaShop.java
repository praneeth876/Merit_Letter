package com.PizzaBillGenerator;

public class PizzaShop {

	public static void main(String[] args) {
//		Pizza pizza=new Pizza("Nonveg");
//		pizza.ShopDetails();
//		pizza.item();
//		System.out.println(pizza.pizzaType+" pizza price :"+pizza.price);
//		System.out.println("Price with extra cheese :"+pizza.addExtraCheese(1));
//		System.out.println("Price with extra toppings : "+pizza.addExtraToppings(2));
//	    pizza.addTakeAways("small");
//	    pizza.totalBill();
	
//	Pizza nonVegpizza=new Pizza("NonVeg");
//	System.out.println(nonVegpizza.pizzaType+" pizza price :"+nonVegpizza.price);
//	System.out.println("Price with extra cheese :"+nonVegpizza.addExtraCheese(1));
//	//System.out.println("Price with extra toppings : "+pizza.addExtraToppings(2));
//	nonVegpizza.addTakeAways("small");
//	nonVegpizza.totalBill();
	
	
	DeluxPizza dp=new DeluxPizza("NonVeg",600);
	dp.ShopDetails();
	dp.item();
	System.out.println("Type of delux pizza :"+dp.PizzaType);
	System.out.println("Price of delux pizza :"+dp.price);
	
	dp.addTakeAways("large");
	dp.totalBill();
}
	
	
}
