package seleniumTopics;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DatePicker {

	static WebDriver driver;
	WebElement monthElement;
    String month;

	public static void main(String[] args) throws InterruptedException {
		DatePicker pick=new DatePicker();
		pick.method("November 2023",25);
	
	}	
		
	public void method(String monthAndYear,int day) throws InterruptedException {	
		WebDriverManager.chromedriver().setup();

	driver= new ChromeDriver();
	driver.manage().window().maximize();

	driver.get("https://jqueryui.com/datepicker/");

	 

	By exampleL =By.cssSelector("div.demo-list>h2");

	WebElement example=driver.findElement(exampleL);

	JavascriptExecutor javascriptexecutor= (JavascriptExecutor)driver;

	javascriptexecutor.executeScript("arguments[0].scrollIntoView(true)",example );
	//WebElement frame=driver.findElement(By.cssSelector("[class=\"demo-frame\"]"));
	driver.switchTo().frame(0);
	driver.findElement(By.id("datepicker")).click();
	
	
	monthElement=driver.findElement(By.xpath("//span[@class=\"ui-datepicker-year\"]/preceding-sibling::span/parent::div"));
//	WebElement days=driver.findElement(By.xpath("//table[@class=\"ui-datepicker-calendar\"]"));
	//List<WebElement> dates=days.findElements(By.tagName("td"));
	//System.out.println(dates.size());
	//WebElement nextElement=driver.findElement(By.cssSelector("[class=\"ui-icon ui-icon-circle-triangle-e\"]"));
	Thread.sleep(5000);
	// String month;
	month=monthElement.getText();
	//System.out.println(month);
		int count=0;
		
		//while(true) {
		for(int i=0;i<12;i++) {
		if(!month.equals(monthAndYear)) {
			//nextElement.click();
			driver.findElement(By.cssSelector("[class=\"ui-icon ui-icon-circle-triangle-e\"]")).click();
			month=driver.findElement(By.xpath("//span[@class=\"ui-datepicker-year\"]/preceding-sibling::span/parent::div")).getText();
			
		}else {
			//System.out.println(month);
			WebElement days=driver.findElement(By.xpath("//table[@class=\"ui-datepicker-calendar\"]"));
			List<WebElement> dates=days.findElements(By.tagName("td"));
			List<WebElement> column=dates.get(i).findElements(By.tagName("a"));
			for(WebElement webDates:column) {
				String num=webDates.getAttribute("data-date");
				System.out.println(num);
				int conNum=Integer.parseInt(num);
				if(conNum==day) {
					driver.findElement(By.xpath("//a[@class='ui-state-default' and @data-date='"+day+"']")).click();
					//break;
				}
		}
		
		
	}
		}
	
	//for(String s:)
	
	
	//for(String s: month)
//	for(int i=0;i<12;i++) {
//		if(month.equals("November 2023")) {
//		System.out.println("november");
//		break;
//	}else {
//		driver.findElement(By.cssSelector("[title=\"Next\"]")).click();
//	}
	
	
	}}

	

	
	
	
	
	
