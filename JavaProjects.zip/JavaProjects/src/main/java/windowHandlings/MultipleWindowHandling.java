package windowHandlings;

import java.time.Duration;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class MultipleWindowHandling {
	
public static WebDriver driver;
static String homePageTitle="Shirts";
static String particularShirtTitle;


	public static void main(String[] args) throws InterruptedException {
		
	
	WebDriverManager.chromedriver().setup();
	
	driver=new ChromeDriver();
	driver.get("https://www.google.com");
	driver.manage().window().maximize();
	driver.findElement(By.id("APjFqb")).sendKeys("myntra");
	Actions action=new Actions(driver);
	action.sendKeys(Keys.ENTER).build().perform();
	driver.findElement(By.xpath("//div[@class=\"eKjLze\"]//h3[@class=\"LC20lb MBeuO DKV0Md\"]")).click();

	driver.findElement(By.cssSelector("[class=\"desktop-searchBar\"]")).sendKeys("shirts");
	Thread.sleep(5000);
	action.sendKeys(Keys.ENTER).build().perform();
	homePageTitle=driver.getTitle();
	System.out.println("In main "+homePageTitle);
	
	particularShirtTitle=driver.findElement(By.xpath("//h3[text()='Roadster']")).getText();
	
	WebElement oneshirt=driver.findElement(By.cssSelector("[class=\"img-responsive\"]"));
	WebDriverWait wait=new WebDriverWait(driver,15);
	wait.until(ExpectedConditions.elementToBeClickable(oneshirt));
	oneshirt.click();

	windowhandling(particularShirtTitle);
	

	WebElement addToBag=driver.findElement(By.xpath("//div[text()=\"ADD TO BAG\"]"));
	WebDriverWait wait1=new WebDriverWait(driver,15);
	wait.until(ExpectedConditions.elementToBeClickable(addToBag));
	addToBag.click();
	Thread.sleep(5000);
	System.out.println("Add to cart");
	windowhandling(homePageTitle);
	
	driver.findElement(By.xpath("//span[text()=\"Profile\"]")).click();
	System.out.println("In homePage");
	
}
	public static void windowhandling(String title) {
		Set<String> allWindows=driver.getWindowHandles();
		

		for(String window : allWindows) {
			
			String allWindowTitles=driver.switchTo().window(window).getTitle();
			System.out.println(allWindowTitles);
			if(allWindowTitles.equals(title)) {
				System.out.println("Inside If "+allWindowTitles);
				//driver.switchTo().window(allWindowTitles);
				break;
			}
		}
	}
}