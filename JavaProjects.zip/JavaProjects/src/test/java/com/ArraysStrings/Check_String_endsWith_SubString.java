package com.ArraysStrings;

import java.util.Scanner;

public class Check_String_endsWith_SubString {
public static void main(String[] args) {
	
	Scanner scan=new Scanner(System.in);
	System.out.println("Enter full name");
	String fullName=scan.nextLine();
	
	System.out.println("Enter subString name");
	String subName=scan.nextLine();
	
	char[] fullNameArray=fullName.toCharArray();
	char[] subNameArray=subName.toCharArray();
	int count=0;
	
	for(int i=0;i<subNameArray.length;i++) {
		
			if(subNameArray[subNameArray.length-1-i]==fullNameArray[fullNameArray.length-1-i])
			{
			count++;
			}
			}
			if(count==subNameArray.length)
			{
			System.out.print("Ends with substring");
			}
			else
			{
			System.out.print("Does not ends with substring");
			}
			}
}