package com.ArraysStrings;

import java.util.Scanner;

public class Check_subString_present_In_FullString {
public static void main(String[] args) {
	Scanner scan=new Scanner(System.in);
	System.out.println("Enter full name");
	String fullString=scan.nextLine();
	
	System.out.println("Enter subString name");
	String subString=scan.nextLine();
	
	char[] fullNameArray=fullString.toCharArray();
	char[] subNameArray=subString.toCharArray();
	int count;
	
	for(int i=0;i<fullNameArray.length;i++) {
		count=0;
		for(int j=0;j<subNameArray.length;j++) {
			if(subNameArray[j]==fullNameArray[i+j]) {
				count++;
				
				System.out.println(fullNameArray[i]+":"+subNameArray[i+j]);
			}
			
		}
		System.out.println(count);
		if(count==subNameArray.length) {
			System.out.println("name is present");
			break;
		}else {
			System.out.println("name is not present");
			break;
		}
		}
	
	
}
}
