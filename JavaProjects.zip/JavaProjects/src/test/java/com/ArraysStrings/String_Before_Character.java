package com.ArraysStrings;

import java.util.Scanner;

public class String_Before_Character {
public static void main(String[] args) {
	Scanner scan=new Scanner(System.in);
	String name=scan.next();
	
	char[] ch=name.toCharArray();
	String temp = "";
	
	for(int i=0;i<ch.length-1;i++) {
		
		if(!(ch[i]=='@')) {
			temp=temp+ch[i];
		}
		else {
			break;
		}
	}
	String nam=temp;
	System.out.println(nam);
	
	
	
	// Example :
	
	// Input  -  Praneeth@abc
	// Output -  Praneeth
	
	
}
}
