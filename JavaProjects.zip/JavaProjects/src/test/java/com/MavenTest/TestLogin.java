package com.MavenTest;

import java.io.IOException;

import org.testng.annotations.Test;

import com.MavenLogin.UserLogin;

public class TestLogin {
	public UserLogin login;
@Test
public void ValidCredentials() throws IOException {
	 login=new UserLogin();
	login.loginPage("Praneeth", "Pran@123");
	
}
@Test
public void InValidCredentials() throws IOException {
	 login=new UserLogin();
	login.loginPage("Praneeth", "Praneeth@123");
}
}
