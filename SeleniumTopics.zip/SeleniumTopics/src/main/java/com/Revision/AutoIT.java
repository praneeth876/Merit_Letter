package com.Revision;

import java.io.IOException;

public class AutoIT {

	
	public static void main(String[] args) throws IOException {
		Runtime.getRuntime().exec("");
	}
}
