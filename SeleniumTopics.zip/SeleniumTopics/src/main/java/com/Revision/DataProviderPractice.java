package com.Revision;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.hpsf.Array;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DataProviderPractice {
	WebDriver driver;
	 //String data;
	WebDriverWait wait;

	@BeforeTest
	public void setUp() {
		WebDriverManager.edgedriver().setup();
		driver=new EdgeDriver();
		driver.get("https://login.salesforce.com/");
		driver.manage().window().maximize();
	}
	@AfterTest
	public void tearDown() {
		driver.close();
	}
	
	public void elementToBeClickable(int time, WebElement element) {
		wait = new WebDriverWait(driver, Duration.ofSeconds(time));
		wait.until(ExpectedConditions.elementToBeClickable(element));
	}
	public void visibilityOfElement(int time, WebElement element) {
		wait = new WebDriverWait(driver, Duration.ofSeconds(time));
		wait.until(ExpectedConditions.visibilityOf(element));
	}
	public void Click(WebDriver driver,WebElement element) {
		JavascriptExecutor js=((JavascriptExecutor)driver);
		js.executeScript("arguments[0].click", element);
	}
	
	@Test(dataProvider = "excelData", dataProviderClass = DataProviderPractice.class)
	public void dataProviderMethod(String Credentials) throws EncryptedDocumentException, IOException, InterruptedException {
		//String Credentials
		
		String[] data=Credentials.split(",");
		String UserName=data[0];
		String PassWord=data[1];
		
		String acttitle=driver.getTitle();
		
		if(acttitle.contains("Login")) {
			WebElement username=driver.findElement(By.id("username"));
			username.sendKeys(UserName);
			WebElement password=driver.findElement(By.id("password"));
			password.sendKeys(PassWord);
			WebElement login=driver.findElement(By.id("Login"));	
			login.click();
			
			String homePageTitle=driver.getCurrentUrl();
			WebElement errorMsg = null;
			if(homePageTitle.contains("dev")) {
				Thread.sleep(40000);
				WebElement img=driver.findElement(By.xpath("//ul[@class=\"slds-global-actions\"]//span[@class=\"uiImage\"]"));
				visibilityOfElement(60,img);
				Click(driver,img);
				//img.click();
				WebElement logout=driver.findElement(By.xpath("//a[text()='Log Out']"));
				elementToBeClickable(20,logout);
				logout.click();
				
			}else {
				errorMsg=driver.findElement(By.cssSelector("div#error"));
				System.out.println(errorMsg.getText());
			}
						
		 if(errorMsg.isDisplayed()){
			username.clear();
			password.clear();
		}
		}
		//excelData();
	
	}
//public static void main(String[] args) throws IOException {
//	excelData();
//}

	@DataProvider
	public static String[] excelData() throws IOException {

		FileInputStream file = new FileInputStream("./src/main/resources/DropdownList1.xlsx");
		Workbook workbook = WorkbookFactory.create(file);
		Sheet sheet = workbook.getSheet("SalesforceMultipleData");
		 String[] Credentials = new String[sheet.getLastRowNum()];
		for (int i = 1; i < sheet.getLastRowNum(); i++) {
				String Usernamedata = sheet.getRow(i + 1).getCell(0).getStringCellValue();
				String Passworddata = sheet.getRow(i + 1).getCell(1).getStringCellValue();
				
				  Credentials[i]= Usernamedata+","+Passworddata;
				 System.out.println(Credentials[i]);
				
		}
		return Credentials;
	}

}
