package com.Revision;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DropDownValuesWriteInExcel {
	static WebDriver driver;

	public static void main(String[] args) throws IOException {

		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();

		driver.get("https://www.amazon.in");
		driver.manage().window().maximize();

		FileInputStream file = new FileInputStream("./src/main/resources/DropdownList1.xlsx");
		XSSFWorkbook workbook = new XSSFWorkbook(file);
		XSSFSheet sheet = workbook.getSheet("Sheet1");

		WebElement dropDown = driver.findElement(By.id("searchDropdownBox"));
		List<WebElement> total = dropDown.findElements(By.tagName("Option"));

		for (int i = 0; i <= total.size() - 1; i++) {
			String text = total.get(i).getText();

			XSSFRow row = sheet.createRow(i);
			XSSFCell cell = row.createCell(0);
			cell.setCellValue(text);
		}
		FileOutputStream fileOut = new FileOutputStream("./src/main/resources/DropdownList1.xlsx");
		workbook.write(fileOut);
		fileOut.flush();
	}
}
