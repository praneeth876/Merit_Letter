package com.Revision;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.Markup;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ExtendReportsPractice {
	public static WebDriver driver;
//ExtentSparkReporter exHtml;
ExtentReports reports;
ExtentTest test;
	
	@BeforeTest
	void initialize() {
		WebDriverManager.edgedriver().setup();
		driver=new EdgeDriver();
		driver.get("https://www.flipkart.com");
		driver.manage().window().maximize();
	}
	
	@Test
	void mainTest() {
		ExtentSparkReporter exHtml=new ExtentSparkReporter("practiceExtentReports.html");
		reports=new ExtentReports();
		reports.attachReporter(exHtml);
		test=reports.createTest("add Test","Description");
		
			
		
		String path="./Screenshots/pic.Png";
		test.addScreenCaptureFromPath("path");
		
		test.log(Status.PASS ,MarkupHelper.createLabel("Method",ExtentColor.GREEN));
		
	}
	
	@AfterTest
	void tearDown(){
		
	}
	
	
}
