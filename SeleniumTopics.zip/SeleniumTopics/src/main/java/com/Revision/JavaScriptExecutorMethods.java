package com.Revision;

import java.io.IOException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class JavaScriptExecutorMethods {

	
	public static WebDriver driver;
	JavascriptExecutor js;

	
	public void elementHighlighter(WebDriver driver,WebElement element) {
		js = ((JavascriptExecutor) driver);
		js.executeScript("arguments[0].style.border='3px solid red'",element);
			
	}
	public void scrollToElement(WebElement element, WebDriver driver) {

		js = ((JavascriptExecutor) driver);
		js.executeScript("arguments[0].scrollBy", element);
	}

	public void getPageTitle(WebElement element, WebDriver driver) {

		js = ((JavascriptExecutor) driver);

		js.executeScript("return document.title");
	}

	public void flash(WebElement element, WebDriver driver) {

		String cssColor = element.getCssValue("backgroundColor");
		for (int i = 0; i < 50; i++) {
			changeColor(element, driver, "#000000");
			changeColor(element, driver, cssColor);
		}
	}

	public void changeColor(WebElement element, WebDriver driver, String color) {
		js = ((JavascriptExecutor) driver);
		js.executeScript("arguments[0].style.backgroundColor='" + color + "'", element);
	}
	
}
