package com.Revision;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ScreenShot {

	public static WebDriver driver;
//	JavaScriptExecutorMethods js=new JavaScriptExecutorMethods();
	public static void main(String[] args) throws IOException {
		
		WebDriverManager.edgedriver().setup();
		driver=new EdgeDriver();
		driver.get("https://www.flipkart.com");
		driver.manage().window().maximize();
		
		driver.switchTo().newWindow();
		
//		File srcFile=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
//		FileUtils.copyFile(srcFile,new File("./Screenshots/pic.Png"));
//		
//		WebElement search=driver.findElement(By.xpath("//input[@title=\"Search for Products, Brands and More\"]"));
//		
//		JavaScriptExecutorMethods js=new JavaScriptExecutorMethods();
//		js.changeColor(search,driver,"green");
				
	}
	   
	
}
