package com.Revision;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ShadowDOM {

	
	public static void main(String[] args) throws InterruptedException {
		
	WebDriver driver;
	WebDriverManager.edgedriver().setup();
	driver=new EdgeDriver();
	driver.get("https://www.salesforce.com/in/");
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	
	
//	WebElement element=driver.findElement(By.tagName("hgf-c360nav")).getShadowRoot()
//			           .findElement(By.tagName("hgf-c360login")).getShadowRoot()
//			           .findElement(By.tagName("hgf-button")).getShadowRoot()
//			           .findElement(By.cssSelector("button.hgf-button"));

	
	
	JavascriptExecutor js=(JavascriptExecutor)driver;
	WebElement shadowDOM2=(WebElement)js.executeScript("return document.querySelector('hgf-c360nav').shadowRoot.querySelector('header.c360-nav > div > div > div > div > hgf-search').shadowRoot.querySelector('hgf-button').shadowRoot.querySelector('a.hgf-button')");
	//Thread.sleep(10000);
//	
//	//WebDriverWait wb=new WebDriverWait(driver,10);
//	explicitWait(driver,shadowDOM2);
	js.executeScript("arguments[0].style.border='3px solid red'",shadowDOM2);
//	js.executeScript("arguments[0].click",shadowDOM2);
//	
	
//	WebElement root1=(WebElement) driver.findElement(By.tagName("hgf-c360nav")).getShadowRoot();
//	WebElement root2=(WebElement) root1.findElement(By.cssSelector("header.360nav > div:nth-child(4)> hgf-search")).getShadowRoot();
//	WebElement root3=(WebElement) root2.findElement(By.cssSelector("div > hgf-button")).getShadowRoot();
//	WebElement searchelement=root3.findElement(By.cssSelector("a.hgf-button"));
//	explicitWait(driver,searchelement);
//	js.executeScript("arguments[0].style.border='3px solid red'",searchelement);
//	}
//	public static WebElement getShadowDOM(WebElement element,WebDriver driver) {
//		JavascriptExecutor js=(JavascriptExecutor)driver;
//		WebElement shadowDOM1=(WebElement)js.executeScript("return arguments[0].shadowRoot",element);
//		
//		return shadowDOM1;
	}
	

	
	public static void explicitWait(WebDriver driver, WebElement element) {
		WebDriverWait  wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.elementToBeClickable(element));
	
	}
	
	
}