package com.Revision;

public class WebTable {

}
