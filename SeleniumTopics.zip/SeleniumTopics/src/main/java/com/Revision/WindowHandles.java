package com.Revision;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class WindowHandles {

	
	public static WebDriver driver;
	public static void main(String[] args) throws IOException {
		
		WebDriverManager.edgedriver().setup();
		driver=new EdgeDriver();
		driver.get("https://www.hyrtutorials.com");
		driver.manage().window().maximize();
		
		
		
	}
}
