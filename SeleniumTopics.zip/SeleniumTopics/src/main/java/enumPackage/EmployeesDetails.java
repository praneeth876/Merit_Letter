package enumPackage;

public enum EmployeesDetails {

	PRANEETH,VAMSY("Viz",30000),UDAY("ViZ",25000),IMRAN("HYD",28000),;
	
	String location;
    int salary;
	
    EmployeesDetails(){
    	
    }
    
	EmployeesDetails(String location,int salary) {
		this.location=location;
		this.salary=salary;
	}
	
	static class mainClass{
		public static void main(String[] args) {
			EmployeesDetails ed=EmployeesDetails.PRANEETH;
			if(ed==EmployeesDetails.PRANEETH) {
				System.out.println(ed.name()+" : "+ ed.location+" : "+ed.salary);
			}
		}
	}	
}
