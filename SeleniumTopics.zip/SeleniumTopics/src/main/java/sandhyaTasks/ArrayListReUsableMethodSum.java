package sandhyaTasks;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ArrayListReUsableMethodSum {
	static int sum=0;
	static ArrayListReUsableMethodSum meth=new ArrayListReUsableMethodSum();
	Scanner scan;
	public static void main(String[] args) {
		System.out.println("Enter no of digits to be added");
		meth.scan=new Scanner(System.in) ;
		int num0=meth.scan.nextInt();
		meth.totalNumbers(num0);
		System.out.println("Sum of all the numbers:"+sum);
	}
	public void totalNumbers(int total) {
		System.out.print("Enter"+total+"nums");
		for (int a=0;a<total;a++) {	
			int num=scan.nextInt();
			meth.addition(meth.arr(num));
		}
	}
	
	public  ArrayList<Integer> arr(int num){
		ArrayList<Integer> list=new ArrayList<>();
		list.add(num);
		return list;
	}
	
	public  void addition(ArrayList<Integer> add) {
		for(int i=0;i<add.size();i++) {
		sum=sum+add.get(i);
		}
		
	}
	
	
}
