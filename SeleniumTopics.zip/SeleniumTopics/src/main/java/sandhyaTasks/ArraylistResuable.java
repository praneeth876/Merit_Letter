package sandhyaTasks;

import java.util.ArrayList;
import java.util.List;

public class ArraylistResuable {
int sum=0;
	
public static void main(String[] args) {
	ArraylistResuable res=new ArraylistResuable();
	res.addition();
}

	public  List<Integer> addition(List<Integer> num) {
		List<Integer> arr=new ArrayList<>();
		arr.addAll(num);
		
//		for(int i=0;i<arr.size();i++) {
//		sum=sum+arr.get(i);
//		}
		return arr;
	}
	
		
	
	
}
